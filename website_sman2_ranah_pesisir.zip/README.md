# Website SMAN 2 Ranah Pesisir

## Isi
- `index.html` — halaman utama website.
- Menu **ASPIRASI SISWA** dan tombol **Sampaikan Aspirasi** menuju Google Form yang diberikan.

## Cara menerbitkan melalui GitHub Pages
1. Masuk ke GitHub dan buat repository baru, misalnya `sman2-ranah-pesisir`.
2. Unggah file `index.html` ke bagian utama (root) repository.
3. Buka **Settings → Pages**.
4. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
6. Tunggu proses penerbitan selesai. GitHub akan menampilkan alamat website pada halaman Pages.

## Catatan penting tentang Google Form
Tautan aspirasi pada website menggunakan URL persis seperti yang diberikan. Pastikan tautan tersebut merupakan tautan untuk responden dan pengaturan formulir mengizinkan siswa mengisi. Jika tautan `publish-editor` membuka halaman pengelolaan formulir, ganti URL di `index.html` dengan tautan responden dari tombol **Kirim/Send → Salin link** di Google Forms.
